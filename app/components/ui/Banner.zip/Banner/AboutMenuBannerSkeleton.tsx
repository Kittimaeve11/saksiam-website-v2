"use client";

import { Box } from "@mui/material";

export default function AboutMenuBannerSkeleton() {
  return (
    <Box
      sx={{
        width: "100vw",
        ml: "calc(50% - 50vw)",
        mr: "calc(50% - 50vw)",
        px: { xs: 2, md: 4 },
        py: { xs: 2, md: 3 },
        boxSizing: "border-box",
      }}
    >
      <Box
        sx={{
          width: "100%",
          minHeight: { xs: 280, sm: 360, md: 460 },
          borderRadius: { xs: "18px", md: "28px" },
          background:
            "linear-gradient(90deg, #EEF2F7 0%, #F8FAFC 45%, #EEF2F7 100%)",
          backgroundSize: "220% 100%",
          animation: "aboutBannerPulse 1.4s ease-in-out infinite",
          "@keyframes aboutBannerPulse": {
            "0%": { backgroundPosition: "100% 0" },
            "100%": { backgroundPosition: "-100% 0" },
          },
        }}
      />
    </Box>
  );
}
